#  Scrolling Indicator

Dieses Beispiel stellt einen Scrolling Indicator dar, damit man bei langen Dokumenten weiss, an welcher Stelle man sich befindet. 

Quelle: https://dev.to/leonardoschmittk/how-to-make-a-scroll-indicator-bar-with-js-html-and-css-easily-and-explained-2jbg

